<?php
	
remove_action( 'wp_head', 'wp_enqueue_scripts');
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_generator' );

add_theme_support( 'custom-background' );
add_theme_support( 'post-thumbnails' );

